# 轻量用户与署名模块说明

## 这次解决什么

第一版不做复杂账号注册，只做「昵称 + 项目码 + 角色码」。

用户第一次进入小程序会被引导到「我的身份」页，填写：

```text
姓名/昵称
项目码
角色码
备注（可选）
```

保存后，前端会把匿名 `operator_token` 存在本机缓存里。之后所有修改类请求都会自动带：

```text
x-operator-token
x-project-code
```

后端用它判断当前操作者是谁、是什么角色，并记录“谁创建/编辑/删除了什么”。

## 默认角色码

如果没有配置环境变量，默认角色码是：

```text
管理员：admin      mulan-admin
协作者：editor    village-editor
只读：viewer      village-viewer
```

建议正式使用时在扣子环境变量里配置：

```text
ADMIN_CODE
EDITOR_CODE
VIEWER_CODE
```

## 权限规则

```text
管理员：admin
- 可以新增、编辑、删除
- 可以查看全部操作记录

协作者：editor
- 可以新增话题、子话题、资料、采访整理
- 可以编辑受访人档案和授权状态
- 不能删除话题、子话题和资料

只读：viewer
- 可以查看
- 不能新增、编辑、删除
```

## 已接入署名的地方

- 话题管理页：显示创建者、最近编辑者。
- 话题详情页：显示话题/子话题创建者、最近编辑者。
- 子话题材料页：采访摘录显示整理人，外部文献显示添加者。
- 授权管理页：受访人 profile 显示建档人和最近确认人。
- 我的身份页：显示当前身份和最近操作。

## 新增接口

```text
POST /api/operators/identify
GET /api/operators/me
POST /api/operators/switch-project
GET /api/activity-logs?target_type=&target_id=
```

写入类接口会要求已有身份：

```text
POST /api/topics
DELETE /api/topics/:id
POST /api/topics/:id/subtopics
DELETE /api/topics/:id/subtopics/:subId
POST /api/topics/:id/subtopics/:subId/auth
POST /api/topics/:id/interviewees/:intervieweeId/authorization
POST /api/materials
PUT /api/materials/:id
DELETE /api/materials/:id
POST /api/interview-plans/generate
POST /api/interview-records/upload-audio
POST /api/interview-records/transcribe
POST /api/interview-records/transcribe-text
```

## 数据库要求

先执行：

```text
DATABASE_IDENTITY_PATCH.sql
```

它会新增：

```text
operators
activity_logs
```

并给以下表补署名字段：

```text
topics
subtopics
interview_records
interviewees
reference_materials
authorization_records
```

## 注意

这不是严格账号登录，只用于项目内署名和防误操作。

换设备时可以重新设置名字和角色码；同名用户会依靠本机 `operator_token` 区分。
