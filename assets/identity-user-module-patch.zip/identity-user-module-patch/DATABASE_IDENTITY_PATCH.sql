create table if not exists operators (
  id varchar(36) primary key default (gen_random_uuid())::text,
  project_id varchar(100) not null default 'village-memory',
  display_name varchar(100) not null,
  role varchar(20) not null default 'viewer',
  operator_token varchar(120) not null,
  note text,
  created_at timestamptz not null default now(),
  last_seen_at timestamptz
);

create index if not exists operators_project_id_idx on operators (project_id);
create index if not exists operators_token_idx on operators (operator_token);
create index if not exists operators_role_idx on operators (role);

create table if not exists activity_logs (
  id varchar(36) primary key default (gen_random_uuid())::text,
  project_id varchar(100) not null default 'village-memory',
  operator_id varchar(36) references operators(id) on delete set null,
  operator_name varchar(100),
  action_type varchar(60) not null,
  target_type varchar(60) not null,
  target_id varchar(36),
  target_name varchar(255),
  summary text not null,
  created_at timestamptz not null default now()
);

create index if not exists activity_logs_project_id_idx on activity_logs (project_id);
create index if not exists activity_logs_operator_id_idx on activity_logs (operator_id);
create index if not exists activity_logs_target_idx on activity_logs (target_type, target_id);

alter table topics add column if not exists created_by varchar(36);
alter table topics add column if not exists created_by_name varchar(100);
alter table topics add column if not exists updated_by varchar(36);
alter table topics add column if not exists updated_by_name varchar(100);

alter table subtopics add column if not exists created_by varchar(36);
alter table subtopics add column if not exists created_by_name varchar(100);
alter table subtopics add column if not exists updated_by varchar(36);
alter table subtopics add column if not exists updated_by_name varchar(100);

alter table interview_records add column if not exists created_by varchar(36);
alter table interview_records add column if not exists created_by_name varchar(100);
alter table interview_records add column if not exists updated_by varchar(36);
alter table interview_records add column if not exists updated_by_name varchar(100);

alter table interviewees add column if not exists created_by varchar(36);
alter table interviewees add column if not exists created_by_name varchar(100);
alter table interviewees add column if not exists updated_by varchar(36);
alter table interviewees add column if not exists updated_by_name varchar(100);

alter table reference_materials add column if not exists created_by varchar(36);
alter table reference_materials add column if not exists created_by_name varchar(100);
alter table reference_materials add column if not exists updated_by varchar(36);
alter table reference_materials add column if not exists updated_by_name varchar(100);

alter table authorization_records add column if not exists operator_id varchar(36);
alter table authorization_records add column if not exists operator_name varchar(100);
create index if not exists authorization_records_operator_id_idx on authorization_records (operator_id);
